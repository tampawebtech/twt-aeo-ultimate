<?php
/**
 * Bulk OG Image Generation (background job)
 *
 * Generates Open Graph share images in the background with OpenAI's
 * gpt-image-2 text-to-image pipeline (using its native text rendering for a
 * clean typographic title overlay), then sideloads each result into the media
 * library and wires it up as the post's OG image.
 *
 * Design notes:
 *   - Engine: Action Scheduler when available (timeout-resistant for high
 *     volume); otherwise a single WP-Cron event whose batches are also driven
 *     by the admin status poll, so the queue still drains on sites where
 *     WP-Cron does not fire reliably.
 *   - Crop bypass: image optimizers (Smush, Imagify, ShortPixel, EWWW, …) and
 *     WordPress itself generate a full set of thumbnail / Next-Gen crops on
 *     every upload. For these one-off social assets we suppress sub-size
 *     generation around the sideload to avoid ballooning disk usage.
 *
 * @package TWTAEO_Connector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TWTAEO_OG_Image_Job {

	/** Custom post meta holding the generated OG image attachment ID. */
	const META_ATTACHMENT = 'twtaeo_og_image';

	/** Background job storage / coordination. */
	const JOB_OPTION = 'twtaeo_og_img_job';
	const JOB_LOCK   = 'twtaeo_og_img_lock';
	const JOB_HOOK   = 'twtaeo_og_img_batch';
	const AS_GROUP   = 'twtaeo-og-image';

	/** Images are slow + costly. Each batch is fired concurrently (curl_multi),
	 *  so BATCH is also the per-batch concurrency — keep it modest to respect
	 *  OpenAI's tighter image rate limits. */
	const BATCH = 3;
	const GAP   = 15;  // Seconds between batches on the WP-Cron fallback.
	const MAX_BACKOFF = 180; // Cap on the exponential rate-limit backoff (seconds).

	/** Per-user dismissal flag for the optimizer compatibility notice. */
	const NOTICE_DISMISS_META = 'twtaeo_og_img_optimizer_dismissed';

	// ── Registration ────────────────────────────────────────────────────────────

	public static function register_hooks() {
		add_action( self::JOB_HOOK, array( __CLASS__, 'run_batch' ) );
		add_action( 'admin_notices', array( __CLASS__, 'maybe_render_optimizer_notice' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_dismiss_optimizer_notice' ) );
	}

	// ── 1. Compatibility check & admin warning ───────────────────────────────────

	/**
	 * Known image-optimization / thumbnail-regeneration plugins, keyed by a
	 * directory-slug fragment (resilient to free/pro folder variants).
	 *
	 * @return array<string,string> slug-fragment => display name.
	 */
	private static function optimizer_plugins() {
		return array(
			'wp-smush'                 => 'Smush',
			'imagify'                  => 'Imagify',
			'shortpixel-image'         => 'ShortPixel',
			'shortpixel-adaptive'      => 'ShortPixel Adaptive Images',
			'ewww-image-optimizer'     => 'EWWW Image Optimizer',
			'optimole-wp'              => 'Optimole',
			'tiny-compress-images'     => 'TinyPNG (Compress JPEG & PNG)',
			'webp-converter-for-media' => 'WebP Converter for Media',
		);
	}

	/**
	 * Display names of any active optimizer plugins (site + network).
	 *
	 * @return string[]
	 */
	public static function detect_active_optimizers() {
		$active = (array) get_option( 'active_plugins', array() );
		if ( is_multisite() ) {
			$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		}

		$map   = self::optimizer_plugins();
		$found = array();
		foreach ( $active as $plugin ) {
			$plugin = strtolower( (string) $plugin );
			foreach ( $map as $needle => $name ) {
				if ( false !== strpos( $plugin, $needle ) ) {
					$found[ $name ] = $name;
				}
			}
		}

		return array_values( $found );
	}

	/**
	 * Warn (once, dismissible) on the Social Graph screen when an optimizer is
	 * active, since bulk generation produces one full-size asset per post.
	 */
	public static function maybe_render_optimizer_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || false === strpos( (string) $screen->id, 'twt-aeo-social-graph' ) ) {
			return;
		}
		if ( get_user_meta( get_current_user_id(), self::NOTICE_DISMISS_META, true ) ) {
			return;
		}

		$found = self::detect_active_optimizers();
		if ( empty( $found ) ) {
			return;
		}

		$dismiss_url = wp_nonce_url( add_query_arg( self::NOTICE_DISMISS_META, 1 ), self::NOTICE_DISMISS_META );

		printf(
			'<div class="notice notice-warning is-dismissible"><p><strong>%s</strong> %s</p><p>%s</p><p><a href="%s">%s</a></p></div>',
			esc_html__( 'Image optimizer detected:', 'twt-aeo-ultimate' ),
			esc_html( implode( ', ', $found ) ),
			esc_html__( 'Bulk OG-image generation creates one new full-size image per post. With an optimizer active, each upload is re-compressed and may be cropped into multiple thumbnail / WebP / Next-Gen sizes, which can use significant disk space. TWT AEO suppresses the extra crop sizes for these social assets, but your optimizer may still process each full-size file.', 'twt-aeo-ultimate' ),
			esc_url( $dismiss_url ),
			esc_html__( 'Dismiss this warning', 'twt-aeo-ultimate' )
		);
	}

	/** Persist the per-user dismissal of the optimizer notice. */
	public static function maybe_dismiss_optimizer_notice() {
		if ( ! isset( $_GET[ self::NOTICE_DISMISS_META ] ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		check_admin_referer( self::NOTICE_DISMISS_META );

		update_user_meta( get_current_user_id(), self::NOTICE_DISMISS_META, 1 );
		wp_safe_redirect( remove_query_arg( array( self::NOTICE_DISMISS_META, '_wpnonce' ) ) );
		exit;
	}

	// ── Job state ─────────────────────────────────────────────────────────────────

	public static function get_job_state() {
		return wp_parse_args( get_option( self::JOB_OPTION, array() ), array(
			'status'      => 'idle', // idle | running | done | error | stopped
			'queue'       => array(),
			'total'       => 0,
			'done'        => 0,
			'created'     => 0,
			'errors'      => 0,
			'rl_rounds'   => 0, // consecutive rate-limited batches (drives backoff)
			'last_error'  => '',
			'started_at'  => 0,
			'finished_at' => 0,
			'engine'      => 'cron', // action-scheduler | cron
		) );
	}

	/** State without the (large) queue, for AJAX/JS. */
	public static function job_payload() {
		$state = self::get_job_state();
		unset( $state['queue'] );
		$state['running'] = ( 'running' === $state['status'] );
		return $state;
	}

	// ── Queue selection ───────────────────────────────────────────────────────────

	/**
	 * Published posts that have a saved AI meta description but no OG image yet
	 * — these are the ones we can generate a meaningful banner for.
	 *
	 * @param int $limit
	 * @return int[] Post IDs.
	 */
	public static function get_candidates( $limit = 2000 ) {
		$post_types = array( 'post', 'page' );
		if ( class_exists( 'WooCommerce' ) ) {
			$post_types[] = 'product';
		}

		$ids = get_posts( array(
			'post_type'      => $post_types,
			'post_status'    => 'publish',
			'posts_per_page' => $limit,
			'fields'         => 'ids',
			'orderby'        => 'modified',
			'order'          => 'DESC',
			'meta_key'       => TWTAEO_AI_Description::META_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- admin-triggered bulk action, not a front-end query.
			'meta_compare'   => 'EXISTS',
		) );

		return array_values( array_filter( $ids, function ( $id ) {
			$desc = (string) get_post_meta( $id, TWTAEO_AI_Description::META_KEY, true );
			if ( '' === trim( $desc ) ) {
				return false;
			}
			$og = class_exists( 'TWTAEO_OG_Writer' ) ? TWTAEO_OG_Writer::get( $id ) : array();
			return empty( $og['og_image'] );
		} ) );
	}

	// ── Start / stop ──────────────────────────────────────────────────────────────

	/**
	 * Queue every eligible post and dispatch background processing.
	 *
	 * @return array Job payload.
	 */
	public static function start_job() {
		$state = self::get_job_state();
		if ( 'running' === $state['status'] ) {
			return self::job_payload();
		}

		$ids = self::get_candidates( 2000 );
		if ( empty( $ids ) ) {
			return self::job_payload();
		}

		$engine = self::action_scheduler_available() ? 'action-scheduler' : 'cron';

		update_option( self::JOB_OPTION, array(
			'status'      => 'running',
			'queue'       => array_map( 'intval', $ids ),
			'total'       => count( $ids ),
			'done'        => 0,
			'created'     => 0,
			'errors'      => 0,
			'last_error'  => '',
			'started_at'  => time(),
			'finished_at' => 0,
			'engine'      => $engine,
		), false );

		self::dispatch( 5 );

		return self::job_payload();
	}

	/**
	 * Stop a running job. Already-generated images are kept.
	 *
	 * @return array Job payload.
	 */
	public static function stop_job() {
		$state = self::get_job_state();
		if ( 'running' !== $state['status'] ) {
			return self::job_payload();
		}

		$state['queue']       = array();
		$state['status']      = 'stopped';
		$state['finished_at'] = time();
		update_option( self::JOB_OPTION, $state, false );

		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( self::JOB_HOOK, array(), self::AS_GROUP );
		}
		$timestamp = wp_next_scheduled( self::JOB_HOOK );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::JOB_HOOK );
		}
		delete_transient( self::JOB_LOCK );

		if ( class_exists( 'TWTAEO_Logger' ) ) {
			TWTAEO_Logger::info( 'OG image bulk job stopped by user after ' . (int) $state['created'] . ' created.' );
		}

		return self::job_payload();
	}

	// ── Dispatch ──────────────────────────────────────────────────────────────────

	public static function action_scheduler_available() {
		return function_exists( 'as_schedule_single_action' );
	}

	/**
	 * Schedule the next batch via Action Scheduler when available, else a single
	 * WP-Cron event (also driven by the admin status poll).
	 *
	 * @param int $delay Seconds.
	 */
	private static function dispatch( $delay = 0 ) {
		if ( self::action_scheduler_available() ) {
			if ( function_exists( 'as_next_scheduled_action' ) && as_next_scheduled_action( self::JOB_HOOK, array(), self::AS_GROUP ) ) {
				return; // Already queued.
			}
			as_schedule_single_action( time() + (int) $delay, self::JOB_HOOK, array(), self::AS_GROUP );
			return;
		}

		if ( ! wp_next_scheduled( self::JOB_HOOK ) ) {
			wp_schedule_single_event( time() + max( 1, (int) $delay ), self::JOB_HOOK );
		}
	}

	// ── Runner ──────────────────────────────────────────────────────────────────

	/**
	 * Process one batch — fired concurrently (up to BATCH at once) — then chain
	 * the next until the queue drains. Rate-limited posts are re-queued and the
	 * next batch is scheduled with exponential backoff.
	 */
	public static function run_batch() {
		if ( get_transient( self::JOB_LOCK ) ) {
			return;
		}
		set_transient( self::JOB_LOCK, 1, 5 * MINUTE_IN_SECONDS );

		// A concurrent batch can run longer than the default execution cap.
		if ( function_exists( 'set_time_limit' ) ) {
			// phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- Image generation can exceed the default cap; guarded by function_exists.
			set_time_limit( 300 );
		}

		$state = self::get_job_state();
		if ( 'running' !== $state['status'] ) {
			delete_transient( self::JOB_LOCK );
			return;
		}

		$batch = array_splice( $state['queue'], 0, self::BATCH );

		// Build a prompt per post. Posts with no usable description are skipped
		// here without an API call.
		$prompts = array();
		$prep    = array(); // post_id => { alt, filename }
		foreach ( $batch as $post_id ) {
			$context = self::prepare( $post_id );
			if ( is_wp_error( $context ) ) {
				$state['errors']++;
				$state['done']++;
				continue;
			}
			$prompts[ $post_id ] = $context['prompt'];
			$prep[ $post_id ]    = $context;
		}

		if ( ! empty( $prompts ) ) {
			$results      = TWTAEO_AI_Description::request_images_bytes( $prompts );
			$rate_limited = array();

			foreach ( $results as $post_id => $result ) {
				if ( is_wp_error( $result ) ) {
					$code = $result->get_error_code();

					// Throttled — retry this post later, do not count it as failed.
					if ( 'rate_limited' === $code ) {
						$rate_limited[] = $post_id;
						continue;
					}

					// No key is systemic — stop the whole job.
					if ( 'no_key' === $code ) {
						return self::halt( $state, $result->get_error_message() );
					}

					// Any other per-post failure (network, decode, API): skip it.
					$state['errors']++;
					$state['done']++;
					continue;
				}

				$saved = self::store_image( $post_id, $result, $prep[ $post_id ] );
				if ( is_wp_error( $saved ) ) {
					$state['errors']++;
					$state['done']++;
					continue;
				}
				$state['created']++;
				$state['done']++;
			}

			if ( ! empty( $rate_limited ) ) {
				// Put throttled posts back at the front and grow the backoff.
				array_splice( $state['queue'], 0, 0, $rate_limited );
				$state['rl_rounds'] = min( (int) ( $state['rl_rounds'] ?? 0 ) + 1, 6 );
			} else {
				$state['rl_rounds'] = 0;
			}
		}

		// Honour an external stop issued while this batch was running.
		$persisted = get_option( self::JOB_OPTION, array() );
		if ( isset( $persisted['status'] ) && 'running' !== $persisted['status'] ) {
			delete_transient( self::JOB_LOCK );
			return;
		}

		if ( empty( $state['queue'] ) ) {
			$state['status']      = 'done';
			$state['finished_at'] = time();
		}

		update_option( self::JOB_OPTION, $state, false );
		delete_transient( self::JOB_LOCK );

		if ( 'running' === $state['status'] && ! empty( $state['queue'] ) ) {
			$delay = empty( $state['rl_rounds'] )
				? self::GAP
				: (int) min( self::GAP * ( 2 ** $state['rl_rounds'] ), self::MAX_BACKOFF );
			self::dispatch( $delay );
		}
	}

	/**
	 * Resolve a post's prompt + image metadata, or a WP_Error to skip it.
	 *
	 * @param int $post_id
	 * @return array{prompt:string,alt:string,filename:string}|WP_Error
	 */
	private static function prepare( $post_id ) {
		if ( ! get_post( $post_id ) ) {
			return new WP_Error( 'no_post', __( 'Post not found.', 'twt-aeo-ultimate' ) );
		}

		// Fetch the AI meta description already saved to the post.
		$description = (string) get_post_meta( $post_id, TWTAEO_AI_Description::META_KEY, true );
		if ( '' === trim( $description ) ) {
			return new WP_Error( 'no_desc', __( 'No saved AI description to base the image on.', 'twt-aeo-ultimate' ) );
		}

		$title = get_the_title( $post_id );
		$alt   = $title
			/* translators: %s: post title. */
			? sprintf( __( 'Social share image for %s', 'twt-aeo-ultimate' ), $title )
			: __( 'AI-generated social share image', 'twt-aeo-ultimate' );

		return array(
			'prompt'   => self::build_prompt( $post_id, $description ),
			'alt'      => $alt,
			'filename' => 'og-' . (int) $post_id . '-' . gmdate( 'YmdHis' ) . '.png',
		);
	}

	/**
	 * Sideload generated image bytes and wire them up as the post's OG image.
	 *
	 * @param int    $post_id
	 * @param string $bytes   Raw PNG bytes.
	 * @param array  $prep    From prepare(): { alt, filename }.
	 * @return true|WP_Error
	 */
	private static function store_image( $post_id, $bytes, $prep ) {
		// Sideload with crop sizes suppressed.
		$attachment_id = self::sideload_no_crops( $bytes, $prep['filename'], $post_id, $prep['alt'] );
		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}

		// Save the attachment ID to custom post meta.
		update_post_meta( $post_id, self::META_ATTACHMENT, (int) $attachment_id );

		// Wire it up as the live OG image (also makes it show as covered in the
		// Social Graph table — see TWTAEO_OG_Detector).
		if ( class_exists( 'TWTAEO_OG_Writer' ) ) {
			$og             = TWTAEO_OG_Writer::get( $post_id );
			$og['og_image'] = (string) wp_get_attachment_url( $attachment_id );
			if ( empty( $og['og_image_alt'] ) ) {
				$og['og_image_alt'] = $prep['alt'];
			}
			TWTAEO_OG_Writer::save( $post_id, $og );
		}

		return true;
	}

	/**
	 * Stop the job with an error message, releasing the lock.
	 *
	 * @param array  $state
	 * @param string $message
	 */
	private static function halt( $state, $message ) {
		$state['status']      = 'error';
		$state['last_error']  = $message;
		$state['finished_at'] = time();
		update_option( self::JOB_OPTION, $state, false );
		delete_transient( self::JOB_LOCK );
		if ( class_exists( 'TWTAEO_Logger' ) ) {
			TWTAEO_Logger::warning( 'OG image bulk job stopped: ' . $message );
		}
	}

	// ── 3b. Prompt modifier (gpt-image-2 text overlay) ────────────────────────────

	private static function build_prompt( $post_id, $description ) {
		$title = get_the_title( $post_id );
		$brand = get_bloginfo( 'name' );

		$prompt  = 'Design a modern, professional social share banner (Open Graph image) in 1.91:1 landscape, intended as the link preview when the page is shared on Facebook, LinkedIn, or X. ';
		$prompt .= 'Use clean, contemporary styling: a balanced composition, a refined and cohesive colour palette, generous spacing, and a clear focal area. ';

		if ( $title ) {
			$prompt .= 'Render the title as a clean typographic text overlay reading exactly: "' . $title . '". ';
			$prompt .= 'Use crisp, legible, well-kerned typography with strong contrast against the background. ';
		}

		$prompt .= 'The design should visually reflect this summary of the page: "' . $description . '". ';

		if ( $brand ) {
			$prompt .= 'Give it a cohesive, on-brand feel for "' . $brand . '". ';
		}

		$prompt .= 'Spell all text correctly, do not use lorem ipsum, do not invent logos or watermarks, and keep on-image text limited to the title.';

		return $prompt;
	}

	// ── 2. Crop-bypassed sideload ─────────────────────────────────────────────────

	/**
	 * Write image bytes to a temp file and import via media_handle_sideload(),
	 * with intermediate crop sizes suppressed for the duration so neither
	 * WordPress nor active optimizers generate thumbnail / Next-Gen variants.
	 *
	 * @param string $bytes    Raw PNG bytes.
	 * @param string $filename
	 * @param int    $post_id  Parent post.
	 * @param string $alt      Image alt text.
	 * @return int|WP_Error Attachment ID.
	 */
	private static function sideload_no_crops( $bytes, $filename, $post_id, $alt ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		global $wp_filesystem;
		if ( empty( $wp_filesystem ) ) {
			WP_Filesystem();
		}
		if ( empty( $wp_filesystem ) ) {
			return new WP_Error( 'fs_unavailable', __( 'The filesystem is not available to save the image.', 'twt-aeo-ultimate' ) );
		}

		$tmp = wp_tempnam( $filename );
		if ( ! $tmp ) {
			return new WP_Error( 'tmp_failed', __( 'Could not create a temporary file.', 'twt-aeo-ultimate' ) );
		}

		$chmod = defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : false;
		if ( ! $wp_filesystem->put_contents( $tmp, $bytes, $chmod ) ) {
			wp_delete_file( $tmp );
			return new WP_Error( 'write_failed', __( 'Could not write the temporary image file.', 'twt-aeo-ultimate' ) );
		}

		$file_array = array(
			'name'     => sanitize_file_name( $filename ),
			'tmp_name' => $tmp,
		);

		// ── Crop bypass ── block sub-size generation for this asset only.
		add_filter( 'intermediate_image_sizes_advanced', array( __CLASS__, 'force_no_image_sizes' ), 999 );
		$attachment_id = media_handle_sideload( $file_array, $post_id, $alt );
		remove_filter( 'intermediate_image_sizes_advanced', array( __CLASS__, 'force_no_image_sizes' ), 999 );

		if ( is_wp_error( $attachment_id ) ) {
			if ( file_exists( $tmp ) ) {
				wp_delete_file( $tmp );
			}
			return new WP_Error( 'attach_failed', $attachment_id->get_error_message() );
		}

		update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );

		return (int) $attachment_id;
	}

	/**
	 * Filter callback: return no intermediate sizes. Named (not a closure) so it
	 * can be removed cleanly right after the sideload.
	 *
	 * @param array $sizes
	 * @return array Empty.
	 */
	public static function force_no_image_sizes( $sizes ) {
		return array();
	}
}

=== TWT AEO Ultimate ===
Contributors: jadeslair
Tags: aeo, schema, seo, structured data, llms
Requires at least: 6.2
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 2.8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Answer Engine Optimization for WordPress. Structured data, AI crawler controls, E-E-A-T author profiles, and publisher signals — all in one place.

== Description ==

**TWT AEO Ultimate** prepares your WordPress site for the AI-first web. As search shifts from ten blue links to AI-generated answers, the signals that get your content cited — structured schema, author authority, publisher identity, and machine-readable content — matter more than ever.

The plugin is built as a fully modular system. Enable only what your site needs; every feature toggles independently, keeping your admin clean and performance light.

**Core modules:**

= 🤖 AI Ready =

Turn your site into a first-class citizen for AI agents and LLM crawlers with a single toggle.

* **llms.txt & llms-full.txt** — Serves a spec-compliant index file at `/llms.txt` and a curated Markdown handshake at `/llms-full.txt` (for ChatGPT, Perplexity, Claude, etc.) containing clean content stripped of HTML noise.
* **Markdown Content Negotiation** — Automatically serves Markdown via `Accept: text/markdown` HTTP headers to visiting AI agents.
* **Content-Signal Headers** — Outputs draft `Content-Signal` headers (`ai-train`, `search`, `ai-input`) to communicate your data licensing and usage preferences.
* **Agent Search API** — A dedicated REST endpoint (`/wp-json/aeo/v1/search`) for AI agents querying your content.
* **MCP Integration & WebMCP** — Exposes a Model Context Protocol server card and browser injection so local AI assistants can discover your site's capabilities.
* **OAuth / OIDC Discovery** — Supports RFC 9728 Protected Resource Metadata and OAuth Authorization Server discovery for authenticated agent access.
* **Granular Rate Limiting** — Per-IP and per-bot throttling. Block specific crawlers or set custom limits for over 20 bots (GPTBot, Meta-ExternalAgent, AppleBot-Extended, and more).
* **API Catalog** — Generates an RFC 9727 `.well-known/api-catalog` to index your site’s public endpoints.

= 🏢 Company Profile =

Correctly splits your corporate entity (Publisher) from individual writers (Authors) to maximize entity-graph clarity for search engines.

* **Organization JSON-LD Schema** — Generates core publisher fields including legal name, logo, founding year, contact points, and `sameAs` social links.
* **Open Graph Publisher/Author Split** — Outputs explicit `article:publisher` and `article:author` tags connecting content to your brand's Facebook page and to individual writer profiles.
* **Meta Business Sync** — Adds the sitewide `fb:app_id` that most SEO suites omit, unlocking Meta Domain Insights and AI-powered Ad Attribution.
* **SEO Plugin Sync** — One-click import from Yoast SEO or Rank Math. Fills in missing fields without ever overwriting your existing data.

= ✍️ Author & E-E-A-T =

Deep author profiles that build robust Person schema and establish authentic Experience, Expertise, Authoritativeness, and Trustworthiness.

* **Rich Author Metadata** — Fields for job titles, credential lines, areas of expertise, and years of industry experience.
* **Verified Certifications** — Repeatable fields for licenses, credentials, and issuing organizations, output as `EducationalOccupationalCredential` in JSON-LD.
* **Social Profiles** — Connects personal networks (LinkedIn, X, GitHub, YouTube, and more) as `sameAs` links in the author's Person schema.
* **Frontend Enhancements** — Optional author hover cards and schema-driven author boxes.
* **E-E-A-T Completeness Score** — Audits profile strength across 8 core trust signals.

= 🗺️ Smart Sitemap Generator =

Flexible, cached XML sitemaps built to support modern discovery mechanisms.

* **Custom Route Handling** — Generates a dedicated `/aeo-sitemap.xml` with per-post-type controls over inclusion, update frequency, and priority.
* **Transient Caching** — 1-hour transient cache, cleared automatically only on content changes (save, update, delete).
* **Parallel llms-full.txt** — Keeps your sitemap and your `/llms-full.txt` output mirrored automatically.
* **Collision Protection** — Detects active Yoast, Rank Math, or AIOSEO sitemaps and steps aside to avoid duplicates.

= 🔍 Schema Detector & Enhancer =

Scans on-page structure and injects structured schema where your theme or page builder left it out.

* **Semantic Detection** — Monitors and compiles JSON-LD for **FAQs** (`FAQPage`), **Services** (`Service`), and **Contact pages** (`ContactPoint`).

= 🎛️ Command Center =

A unified dashboard showing your site's optimization health and bot activity at a glance.

* **AI Crawler Watch** — Live feed of AI engine visits, breakdown by parent company, most-crawled pages, and direct links to block or throttle specific crawlers.
* **Conflict Resolver** — Flags duplicate schema blocks injected by competing plugins or scripts.
* **Readiness Score** — A real-time score showing how prepared your site is for AI search.

= 🛠️ Specialized Add-ons =

* **Image SEO** — Scans posts and pages for images missing alt text and fills it with AI vision (per item) or a manual edit modal. Writes both the Media Library attachment alt and the empty inline `alt=""` in the content so the live page reflects it. WooCommerce product images are handled on the WooCommerce page.
* **IndexNow** — Instant URL submission to Bing, Yandex, and other compatible engines on publish or update.
* **Local Pack Schema** — `LocalBusiness` output with a NAP (Name, Address, Phone) consistency checker.
* **WooCommerce Bridge + AI Product Enrichment** — Rich `Product` schema (nested Brand, color/material/size, GTIN/MPN, `additionalProperty`, `itemCondition`, variations as `ProductGroup`/`variesBy`, cross-sell/related relationships, `aggregateRating` + reviews, and site-wide shipping/return policies). A per-product AI engine extracts attributes from descriptions, tags visual attributes from product images, generates image alt text, enhances descriptions, standardizes custom attributes to schema.org fields, resolves brand `sameAs` authority links, and flags competitor-expected fields you're missing — across Claude, OpenAI, Gemini, and Perplexity. Includes Google & Bing Merchant Center sync with an integrity score, plus a per-product schema Optimization score in the catalog table.
* **PR Bridge AI** — Press release detection, content restructuring, and wire-service distribution.
* **Content Generator** — In-dashboard, AI-assisted drafting aligned with AEO best practices.

= TWT Agency Connectivity =

This plugin includes optional integration with the **TWT Agency** dashboard for cross-site analytics, historical telemetry, and bulk schema oversight. The plugin remains 100% functional as a standalone install — no paid tier or subscription required.

== Installation ==

1. Upload the entire `twt-aeo-ultimate` folder to your `/wp-content/plugins/` directory.
2. Activate the plugin via the **Plugins** screen in your WordPress dashboard.
3. Go to **TWT AEO → Modules** to review and enable the features you want.
4. Set up your publisher identity under **TWT AEO → Company**.
5. Update your user profiles under **Users → All Users** to complete each author's E-E-A-T data.
6. Configure bot visibility and access controls at **TWT AEO → AI Ready**.

**Important:** After activating, go to **Settings → Permalinks** and click **Save Changes** once. This flushes rewrite rules so the virtual routes for `/llms.txt`, `/llms-full.txt`, and `/aeo-sitemap.xml` resolve correctly.

== Frequently Asked Questions ==

= Does this plugin conflict with Yoast SEO or Rank Math? =
No. TWT AEO Ultimate detects active SEO suites and steps back from any metadata they already output (Organization, Article, Open Graph). It acts as an enhancement layer, adding the signals those suites typically miss — `article:publisher`, rate-limit controls for 20+ AI agents, author credential schema, and `llms.txt` processing.

= What is llms.txt and why do I need it? =
`llms.txt` is an emerging standard (see llmstxt.org) that gives AI systems a clean, machine-readable summary of what your site contains and how to access it. Think of it as a `robots.txt` written for language models. The companion endpoint `/llms-full.txt` serves your content as clean Markdown so crawlers can ingest it without parsing token-heavy HTML.

= Why does the publisher/author Open Graph split matter? =
Standard social tags often blur authorship by failing to separate your brand from the individual writer. TWT AEO Ultimate keeps them distinct: `article:publisher` establishes the company identity, while `article:author` links to the individual author. AI models use this split to assess authority and attribute content accurately.

= What does the Meta Business Sync do? =
It adds the sitewide `fb:app_id` tag, which links your domain to your Meta Developer App. That unlocks the Meta Domain Insights dashboard and helps Meta attribute your content correctly across its ad and AI systems. Most SEO plugins don't output this tag.

= Can I block specific AI bots or engines safely? =
Yes. Under **TWT AEO → AI Ready → Security & Rate Limiting**, each of 20+ known AI crawlers has a Block toggle and a custom rate-limit override. Blocking a bot writes a `Disallow` entry to your virtual `robots.txt` and returns a 403 on its requests — both advisory and hard enforcement.

= Will the rate limiter affect my human visitors? =
No. The filter matches requests by User-Agent against the known AI crawler list only. Regular browsers, ordinary visitors, and traditional search engines (like Googlebot) pass through unaffected.

= Will this add overhead or slow down my site? =
No. Frontend metadata, schema, and virtual assets are served from the WordPress Transients API with a 1-hour cache. Heavier work runs only when a post is saved or settings change. The crawler rate limiter adds a single transient read per page load, and only for known AI agents.

= What are the system requirements? =
PHP 7.4 or higher (PHP 8.0+ recommended) and WordPress 6.0+. For full functionality on WordPress 7.0 and its modern data views, MySQL 8.0 and a PHP memory limit of at least 256MB are recommended.

== Screenshots ==

1. **Command Center** — Real-time AI Crawler Watch monitor and bot traffic breakdown.
2. **AI Ready Configuration** — Per-bot rate limits and block toggles for 20+ AI agents.
3. **Company Profile Manager** — Brand identity fields and Meta Business integration.
4. **Author Profile Extensions** — Custom fields on the WordPress user profile for certifications and credentials.
5. **E-E-A-T Quality Assessment** — Trust-signal scoring across your authors.
6. **Sitemap Generator** — Post-type selection for both XML and Markdown endpoints.
7. **Modules Screen** — Enable or disable each feature independently.

== Changelog ==

= 2.8.0 =

* **Compliance:** Output-escaping pass across the plugin. Inline SVG icons are now escaped through `wp_kses()` with an explicit SVG allow-list; JSON-LD schema output is hardened with the full `JSON_HEX_*` flag set so it is inert in HTML; and the WebMCP tool definitions are handed to the browser via `wp_add_inline_script()` instead of being echoed. Every remaining intentional escape exception is documented inline.
* **Compliance:** All physical-file operations for the `/.well-known/` discovery files (API Catalog, Agent Skills Index, MCP Server Card, OAuth/OIDC) and `robots.txt` now go through the WordPress `WP_Filesystem` API instead of direct PHP filesystem functions.
* **Compliance:** Unique-prefix pass — every element that used the short `twt_` prefix (the Reviews post type and its meta keys, the merchant-sync snapshot meta, nonces, AJAX/redirect parameters, and a transient) now uses the plugin's `twtaeo_` prefix. A one-time, automatic database migration renames existing data so nothing is lost on upgrade.
* **Compliance:** base64 transport-encoding calls (cryptography, AI image payloads, OAuth/JWT, HTTP Basic, the admin-menu data-URI icon) are documented as legitimate, non-obfuscation uses.
* **Security:** The AI Ready settings save now performs independent capability and nonce checks within the handler, and Markdown content negotiation reads its `aeo_format` request flag via a registered query var rather than the raw query string.
* **Feature:** When the server filesystem is not writable, the AI Ready page now shows step-by-step instructions plus the exact, copy-and-paste contents for creating the `/.well-known/` discovery files (and the `robots.txt` Content-Signal/Sitemap directives) by hand.
* **Compliance:** Expanded the External Services disclosures with the optional industry-directory links the plugin can surface, and corrected/removed several directory URLs.

= 2.7.0 =

* **Feature:** New **Image SEO** page — scans posts and pages for images missing alt text and fills it with AI vision per item, or via a manual edit modal when no AI provider is connected. Covers the featured image and images embedded in the content, and writes both the Media Library attachment alt and the empty inline `alt=""` in the post HTML (existing alt text is never overwritten). WooCommerce product images remain on the WooCommerce page.
* **Feature:** Rich WooCommerce Product schema — the per-product schema modal now writes nested Brand, color/material/size, GTIN/MPN, `additionalProperty` custom specs, `itemCondition`, variable products as `ProductGroup` with `variesBy`, cross-sell/related/similar/accessory relationships, `aggregateRating` + individual reviews, and site-wide `OfferShippingDetails` + `hasMerchantReturnPolicy` defaults.
* **Feature:** AI Product Enrichment engine (per-product, on-demand, non-destructive) — extract attributes from descriptions (with unit conversion to your store units), tag visual attributes from the product image (color/pattern/texture/shape), generate image alt text, enhance the description (fact-grounded, with optional write-back to the product), standardize custom attributes into schema.org fields, resolve brand `sameAs` authority links (Wikipedia/Wikidata/official), and flag competitor-expected fields you're missing.
* **Feature:** Shared multi-provider AI client (Claude, OpenAI, Google Gemini, Perplexity) with JSON, web-search grounding, and image (vision) input. New "AI Enrichment" settings let you choose an extraction provider and a live-retrieval provider independently.
* **Feature:** Products table now shows a per-product schema **Optimization score** (9 weighted signals, with the missing ones on hover) and an **image-alt coverage** column — both update live after you save or fill.
* **Improvement:** `/llms.txt` now includes a Products section for WooCommerce stores — links the shop and product categories and declares that the store publishes Schema.org product data for AI shopping agents.
* **Improvement:** Updated AI model IDs to current releases (OpenAI `gpt-5.4-mini`, with correct GPT-5 reasoning-model request parameters; image generation on `gpt-image-2`) and verified Claude/Gemini/Perplexity IDs.
* **Compliance:** Updated the External Services disclosures to cover the new AI uses — WooCommerce product enrichment and Image SEO — and to state that vision features send your own post/product image URLs/contents to the configured AI provider. Added a dedicated Google Gemini API entry. All AI requests remain opt-in, key-gated, and triggered only by an explicit click.

= 2.6.1 =

* **Feature:** AI traffic & citations across the Command Center — a GA4 "AI Assistant Traffic" section (ChatGPT, Gemini, DeepSeek, Copilot, Grok) with per-source sessions, users, and conversions, plus "AI Search" panels on the Search Console and Bing tabs that link out to Google's and Bing's AI performance reports (those stay UI-only until the providers expose APIs).
* **Feature:** Index Status now inspects every published page (not just the 50 most recently edited) and shows the pages that actually need work — sorted worst-first, with a "Needs work / All scanned" toggle and pagination. Google has no bulk index-status export, so each page is inspected individually via the URL Inspection API.
* **Feature:** Inline fixes on the Index Status tab — an "Issues & Fixes" column with a modal to fill Open Graph (title/description/image, with AI generation) and generate FAQ schema without leaving the page.
* **Feature:** Analytics "Top Pages" now includes Bounce Rate, Avg Time, Events, and Conversions plus a plain-language Signal (Converting / Needs work / Likely bots / Healthy) so non-analysts can tell what to act on.
* **Improvement:** Bing tab "Query Statistics" rebuilt as a proper Top Queries table (query, impressions, clicks, CTR, average position) — it previously discarded the query term and showed a bogus -0 position from click-position data.
* **Improvement:** Index Status content check now flags missing heading hierarchy (no H2/H3) instead of a missing in-content H1, since WordPress themes render the post title as the page H1.
* **Improvement:** Modules page descriptions reviewed for accuracy — Social Graph now notes its AI og:description/og:image generation and bulk fill.
* **Fix:** Setup wizard text corrected — sitemap URL now shows the real /aeo-sitemap.xml path, the completion screen links to the Command Center, and Basics step labels match what they configure.
* **Improvement:** Plugin Check pass — annotated the legitimate-but-flagged spots (read-only display filters, core-hook calls, custom merchant-queue table queries, guarded set_time_limit) with justified phpcs:ignore comments. No behavior change.

= 2.6.0 =

* **Feature:** AI Discovery File Hits — the Command Center now tracks how many AI crawlers fetch your machine-readable discovery files (robots.txt, llms.txt, llms-full.txt) over a rolling 30-day window, so you can see whether bots are actually using your structured signals. Per-site hits sync to the agency dashboard.
* **Feature:** "Remove physical robots.txt" button on the AI Ready page — deletes a stranded physical robots.txt (e.g. one left behind by Yoast) so WordPress serves it dynamically again, clearing stale content. No FTP required.
* **Improvement:** The robots.txt panel is now state-aware and recommends the right action per site — confirms when robots.txt is already dynamic and tracked, or guides you to remove/inject when a physical file is in the way. SEO-plugin detection now covers Yoast, Rank Math, All in One SEO, and SEOPress.
* **Improvement:** llms.txt, llms-full.txt, and the dynamic robots.txt now send no-cache headers so a full-page cache (host cache or CDN) doesn't serve them without running WordPress — which would hide AI-crawler hits. The dashboard also flags a physical robots.txt as "not tracked" instead of showing a misleading zero.
* **Fix:** The IndexNow key file now returns HTTP 200 (it was returning 200's body with a 404 status, which made search engines reject it).
* **Fix:** Saving IndexNow settings no longer fails with "The link you followed has expired" — a nested form was causing a nonce conflict.

= 2.5.0 =

* **Feature:** AI Open Graph images — generate a clean, on-brand social share banner (with the post title rendered on it) for a post on demand from the Social Graph editor modal: choose a style and what to base it on, and the image is added to the Media Library and set as the post's og:image. You can optionally reuse it as the post's featured image.
* **Feature:** Stop button for the bulk AI-description job, plus per-provider notes showing each model and its relative speed and limitations.
* **Improvement:** Bulk AI generation is more resilient — a single slow API call that times out is now skipped instead of stopping the whole run (it only gives up after repeated network failures), and the per-request timeout was raised.
* **Improvement:** Pages with too little body text are skipped during AI description generation, since thin pages only produce generic descriptions.
* **Improvement:** Added a "Rescan" button to the Social Graph and Schema Detector pages, with a confirmation when the scan refreshes.
* **Fix:** Google Gemini descriptions are no longer thin or empty — the gemini-2.5 reasoning model was spending its token budget on internal "thinking"; that is now disabled for these short summaries.
* **Fix:** The Social Graph coverage table now reflects the og:title and og:description saved through the AEO editor (previously only the saved image was detected), so saved values no longer show as "missing" after a rescan.
* **Fix:** The Schema Detector FAQ tab now recognises FAQPage schema created by its own "Add FAQ Schema" action, so generated schema no longer keeps showing as "Missing".

= 2.4.1 =

* **Feature:** Bulk AI meta-description generation now runs as a background job — it processes server-side in small batches, shows live progress, and continues if you navigate away (on hosts with working WP-Cron). It also advances directly from the dashboard while the page is open, so it works even where WP-Cron is disabled. The run stops cleanly and shows the provider's message on errors such as no remaining API credits.
* **Feature:** Social Graph — fill missing Open Graph (og:description) values in two ways: reuse the meta descriptions you already have (free and instant) or have AI write share-optimised social copy in the background. The per-post editor modal also gains "Use meta description" and "Generate with AI" buttons.
* **Fix:** Updated the default Google Gemini model to gemini-2.5-flash (gemini-2.0-flash was retired).

= 2.4.0 =

* **Feature:** AI Meta Descriptions — generate concise meta descriptions with Claude, OpenAI, or Google Gemini. Use the per-post "Generate with AI" button in the editor, the bulk "Generate all missing" action on the dashboard, or turn on automatic generation when a post is first saved (existing descriptions are never overwritten). The description is written to the active SEO plugin's field when one is present, and output as a `<meta name="description">` tag when none is.
* **Feature:** Added Google Gemini as an AI provider in Settings (key resolves via the `TWTAEO_GEMINI_KEY` constant/env var or the database, like the other providers).
* **Feature:** Article schema is now output automatically on blog posts that have no SEO plugin supplying it, so posts are no longer left without article-type structured data.
* **Feature:** New Diagnostics page (System Info + recent error log) with one-click copy for support. A centralized logger captures plugin errors — including a plugin-scoped fatal-error catcher — and redacts credentials from log output.
* **Improvement:** NewsArticle schema is now opt-in per post via the "Mark as Google News article" toggle instead of being applied to every post; the news sitemap follows the same flag. This stops evergreen content from being mislabelled as news.
* **Improvement:** E-E-A-T scan now reads your Company Profile and all supported SEO plugins (Yoast, Rank Math, AIOSEO, SEOPress, The SEO Framework) when checking for sameAs links and an Organization name, and the cached scan refreshes automatically when plugins are activated or deactivated.
* **Improvement:** Index-status results now flag `noindex` and mismatched canonical URLs (the real reasons a page stays unindexed), add an "Edit page" shortcut, and explain what actually drives indexing.
* **Fix:** The "Add Certification" button on the user profile now works (its script handle was not enqueued on the profile screen).
* **Fix:** sameAs links saved via the E-E-A-T "Add Links" modal now persist and are detected on rescan.

= 2.3.3 =

* **Compliance:** Plugin Check pass — rewrote database queries cleanly, fixed global-variable usage, and corrected hook-name flags.

= 2.3.2 =

* **Compliance:** Plugin Check compliance pass; declared WordPress 6.2 as the minimum supported version and made the WordPress 7.0 AI Client call conditional.

= 2.3.1 =

* **Security/Guidelines:** The Content Generator now sends Claude and OpenAI requests through the WordPress 7.0 AI Client (`wp_ai_client_prompt()`) when no plugin-owned key is set, so the plugin no longer reads the core Connectors API keys (`connectors_ai_*_api_key`) directly.
* **Security:** The MCP endpoint (`aeo/v1/mcp`) now runs the same permission checks as the Agent Search endpoint — honouring bot-block rules, rate limits, IP allow-list, user-agent verification, and OAuth bearer auth instead of bypassing them. It remains public by default when no restrictions are configured.
* **Performance/Guidelines:** Moved all remaining inline `<style>` and `<script>` blocks (admin pages, the Hub metabox, front-end hub shortcodes, the Last Updated badge) into properly enqueued CSS/JS via `wp_enqueue_*`. JSON-LD schema output remains inline as required.
* **Compliance:** Removed promotional upsell prompts from the AI Crawler Watch and Not Indexed screens; the Not Indexed report now lists every not-indexed page locally instead of capping the free view.
* **Fix:** Corrected the EasyPRWire service domain and its Terms/Privacy links, and updated the EIN Presswire legal links. All External Services disclosures reviewed and verified.

= 2.3.0 =

* **Feature:** Added Google service-account authentication as a no-OAuth alternative for Search Console and Analytics access on agency-managed sites.

= 2.2.2 =

* **Feature:** Social Graph now auto-fills the Open Graph title and image and adds an `og:image:alt` label.
* **Feature:** The Dashboard now scans pages beyond the initial 200-page cap in the background, with progress and a completion notice.

= 2.2.1 =

* **Fix:** Resolved a fatal error when author social/credential meta was stored as an array and passed to `json_decode()`.
* **Branding:** Updated the Modules promo card from "TWT AEO Pro" to "TWT Agency" with an accurate feature list.

= 2.2.0 =

* **Feature:** Content Generator — industry/subtopic-based AI content from Claude, OpenAI, and Perplexity.
* **Feature:** AEO Command Center — Google Analytics, Search Console, and Bing Webmaster integrations.
* **Feature:** Background WooCommerce merchant sync to Google Merchant Center and Bing Merchant Center.
* **Feature:** Connector REST API for the TWT Agency hub, automatic index-status scanning, and remediation endpoints.

= 2.1.1 =

* Renamed the connected dashboard product to **TWT Agency** across the admin UI, settings, and documentation. Sync behavior is unchanged, and existing connection settings are preserved.
* Updated the External Services disclosures and added Privacy Policy / Terms of Use links covering the optional TWT Agency sync and Token Telemetry features.
* Readme polish and WordPress.org formatting and compliance fixes.

= 2.1.0 =

* **Compatibility:** Validated against WordPress 7.0; now requires MySQL 8.0.
* **Feature:** Rebuilt the AI Crawler Watch interface on the WordPress DataViews framework (React) with live client-side filtering, sorting, and status — falling back to a classic table on older environments (< WP 6.5).
* **Integration:** Registered core operations with the WordPress 7.0 Command Palette and Client-Side Abilities API. Schema Conflict Scan and IndexNow Submit All are now available via `Ctrl+K` and core AI assistants.
* **Block Editor:** Added iframe-aware state tracking. The AEO Status metabox now reads block state via the `wp.data` store, avoiding direct DOM access in the iframed editor.
* **Developer:** Added the `TWT_AEO_Key_Resolver` for API credentials, resolved in priority order (PHP constant → environment variable → Connectors → database). Constants are never written to the database.
* **Server Safeguards:** Added environment checks on admin pages that flag low memory conditions (≤ 128MB) which can conflict with WP 7.0 AI features.

= 1.0.17 =

* Added: Company Profile module — Organization schema, `article:publisher` / `article:author` OG split, `fb:app_id` (Meta Business Sync), and Yoast / Rank Math one-click sync.
* Added: Per-bot controls — custom rate limits and Block toggles for 20 known AI crawlers.
* Added: `/llms-full.txt` generation mirrored against your sitemap configuration.

= 1.0.16 =

* Added: Repeatable `EducationalOccupationalCredential` fields on the author profile.
* Added: Configurable frontend author hover cards.

= 1.0.15 =

* Added: XML sitemap generator at `/aeo-sitemap.xml`.
* Added: Conflict detection against external SEO-suite sitemaps.
* Added: IndexNow publishing hooks.

= 1.0.14 =

* Added: AI Ready toolkit — `llms.txt`, agent endpoints, and discovery/authentication routes.
* Added: MCP server configuration.

= 1.0.13 =

* Added: Command Center overview with crawler analytics and a default 30-day log retention.

= 1.0.12 =

* Added: Open Graph and social metadata output with automatic conflict avoidance.

= 1.0.11 =

* Added: Author profile schema and a configurable frontend author box.

= 1.0.10 =

* Added: Schema Detector for FAQ and Service content.
* Added: Local Pack module and LocalBusiness schema.

= 1.0.0 =

* Initial release — module loader, dashboard, settings, and data transmitter.

== External Services ==

This plugin can optionally connect to third-party providers to power AI content generation, image (vision) analysis, structured-data enrichment, indexing, and PR distribution. Connections stay dormant unless you explicitly enable a feature and add your own API credentials in the settings panel. AI requests are only made when you click an AI action; nothing is sent automatically or on activation.

= Anthropic Claude API =

* **Used by:** Content Generator, PR Bridge AI, AI meta descriptions, WooCommerce product enrichment (attribute extraction, description rewriting, attribute standardization), and Image SEO / product image analysis.
* **Data sent:** Your content and prompt text, plus your Anthropic API key. For image features (vision tagging, alt-text generation), the URLs and contents of your own post/product images are also sent. No visitor identity data is sent.
* **Triggers:** Only when you click an AI action (generate content, enhance a description, extract attributes, generate alt text, etc.).
* **Resources:** [Anthropic Acceptable Use Policy](https://www.anthropic.com/legal/aup) | [Anthropic Privacy Policy](https://www.anthropic.com/legal/privacy)

= OpenAI API =

* **Used by:** Content Generator, AI meta descriptions, AI Open Graph image generation, WooCommerce product enrichment, and Image SEO / product image analysis.
* **Data sent:** A content or image prompt and your OpenAI API key. For image analysis features, the URLs and contents of your own post/product images are also sent.
* **Triggers:** Only when you click an AI action, if an OpenAI key is configured.
* **Resources:** [OpenAI Terms of Use](https://openai.com/policies/terms-of-use) | [OpenAI Privacy Policy](https://openai.com/policies/privacy-policy)

= Google Gemini API =

* **Used by:** AI meta descriptions, WooCommerce product enrichment, Image SEO / product image analysis, and web-grounded brand authority (sameAs) and competitive-gap lookups.
* **Data sent:** Your content and prompt text, image URLs/contents for vision features, brand/product names for grounded lookups, and your Gemini API key. Sent to `generativelanguage.googleapis.com`. No visitor identity data is sent.
* **Triggers:** Only when you click an AI action, if a Gemini key is configured.
* **Resources:** [Google Terms of Service](https://policies.google.com/terms) | [Google Privacy Policy](https://policies.google.com/privacy)

= Perplexity AI API =

* **Used by:** Content Generator research, and (optional) WooCommerce brand authority (sameAs) resolution and competitive-gap analysis.
* **Data sent:** A research query or a brand/product name, plus your Perplexity API key.
* **Triggers:** Only on explicit AI actions, if a Perplexity key is configured.
* **Resources:** [Perplexity Terms of Service](https://www.perplexity.ai/hub/legal/terms-of-service) | [Perplexity Privacy Policy](https://www.perplexity.ai/hub/legal/privacy-policy)

= Google APIs (OAuth 2.0, Search Console, Analytics, Knowledge Graph, Business Profile, Merchant Center, Sitemap Ping) =

* **Used by:** Command Center reporting, Local Pack NAP checks, WooCommerce product sync, and sitemap notifications.
* **Data sent:** OAuth tokens, property/account identifiers, product data, or URLs — over standard Google OAuth flows. No end-user personal data is sent.
* **Triggers:** On dashboard reporting, scheduled product sync, or manual checks.
* **Resources:** [Google Terms of Service](https://policies.google.com/terms) | [Google Privacy Policy](https://policies.google.com/privacy)

= Microsoft / Bing APIs (OAuth, Merchant Center, Maps, Webmaster Tools, IndexNow) =

* **Used by:** E-commerce feed sync, NAP/address checks, and indexing.
* **Data sent:** OAuth tokens, structured product data, or published URLs sent to the relevant API endpoints.
* **Triggers:** On content publish/update events or catalog sync intervals.
* **Resources:** [Microsoft Services Agreement](https://www.microsoft.com/en-us/servicesagreement) | [Microsoft Privacy Statement](https://privacy.microsoft.com/en-us/privacystatement)

= IndexNow Network Protocol =

* **Used by:** IndexNow module.
* **Data sent:** Your IndexNow key and the public URLs of published or updated posts, sent to supporting search engines.
* **Triggers:** On post publish/update or manual submission.
* **Resources:** [IndexNow Protocol](https://www.indexnow.org/)

= EIN Presswire =

* **Used by:** PR Bridge AI distribution.
* **Data sent:** Press release headline and body, the source post URL, and your EIN Presswire API key.
* **Triggers:** Only when you click submit on the PR Bridge page.
* **Resources:** [EIN Presswire Terms](https://www.einpresswire.com/legal/terms) | [EIN Presswire Privacy Policy](https://www.einpresswire.com/legal/privacy)

= EasyPRwire =

* **Used by:** PR Bridge AI distribution (alternative provider).
* **Data sent:** Press release headline and body, the source post URL, and your EasyPRwire API key.
* **Triggers:** Only when you click submit on the PR Bridge page.
* **Resources:** [EasyPRWire Terms](https://easyprwire.com/terms-and-condition) | [EasyPRWire Privacy Policy](https://easyprwire.com/privacy-policy)

= TWT Agency (optional) =

* **Used by:** Optional dashboard sync and remote monitoring.
* **Data sent:** Site AEO metrics, AI-crawler events, schema and content activity, analytics summaries, plugin/site info, and your TWT Agency API key. No site-visitor personal data is sent.
* **Triggers:** A daily snapshot plus event-driven pushes, only when a TWT Agency API key and Dashboard URL are configured.
* **Resources:** [TWT Terms of Use](https://tampawebtech.com/plugin-terms/) | [TWT Privacy Policy](https://tampawebtech.com/plugin-privacy-policies/)

= TWT AEO Token Telemetry (optional) =

* **Used by:** Content Generator (anonymous usage reporting to improve the plugin).
* **Data sent:** AI provider name, model slug, plugin version, and token counts only. No content, URLs, titles, API keys, or visitor data.
* **Triggers:** On an AI generation, only if you opt in via Settings.
* **Endpoint:** https://tampawebtech.com/wp-json/twt-aeo/v1/token-telemetry
* **Resources:** [TWT Privacy Policy](https://tampawebtech.com/plugin-privacy-policies/)

= Industry Directory Links (optional) =

The plugin provides optional integrations with major industry directories to enhance your AEO and local-search footprint. Depending on the industry you select in the settings, the plugin may link out to the following external platforms. These are outbound links only — no data is transmitted to these services by the plugin, and you choose which industry (if any) to enable.

**Home Services**

* Angi — https://www.angi.com | [Privacy](https://legal.angi.com/#privacy-policy) | [Terms](https://legal.angi.com/#contract-skmav5s0l)
* Thumbtack — https://www.thumbtack.com | [Privacy](https://www.thumbtack.com/privacy) | [Terms](https://www.thumbtack.com/terms)
* HomeAdvisor — https://pro.homeadvisor.com | [Privacy](https://legal.angi.com/#privacy-policy) | [Terms](https://legal.angi.com/#contract-skmav5s0l)
* Houzz — https://www.houzz.com | [Privacy](https://www.houzz.com/privacyPolicy) | [Terms](https://www.houzz.com/termsOfUse)
* BuildZoom — https://www.buildzoom.com | [Privacy](https://www.buildzoom.com/privacy-policy) | [Terms](https://www.buildzoom.com/terms-of-service)

**Restaurant & Food**

* Yelp — https://biz.yelp.com | [Privacy](https://terms.yelp.com/privacy/en_us/) | [Terms](https://terms.yelp.com/tos/en_us/)
* TripAdvisor — https://www.tripadvisor.com | [Privacy](https://tripadvisor.mediaroom.com/us-privacy-policy) | [Terms](https://www.tripadvisor.com/pages/terms.html)
* OpenTable — https://restaurant.opentable.com | [Privacy](https://www.opentable.com/c/legal/privacy-policy/) | [Terms](https://www.opentable.com/c/legal/terms-and-conditions/)
* Zomato — https://www.zomato.com | [Privacy](https://www.zomato.com/policies/privacy/) | [Terms](https://www.zomato.com/policies/terms-of-service/)
* Foursquare — https://business.foursquare.com | [Privacy](https://foursquare.com/legal/privacy) | [Terms](https://foursquare.com/legal/terms)

**Legal**

* Avvo — https://www.avvo.com | [Privacy](https://www.internetbrands.com/privacy) | [Terms](https://www.internetbrands.com/ibterms)
* FindLaw — https://lawyers.findlaw.com | [Privacy](https://www.findlaw.com/company/privacy/privacy-statement.html) | [Terms](https://www.findlaw.com/company/terms-of-use.html)
* Justia — https://lawyers.justia.com | [Privacy](https://www.justia.com/privacy-policy/) | [Terms](https://www.justia.com/terms-of-use/)
* Martindale-Hubbell — https://www.martindale.com | [Privacy](https://www.internetbrands.com/privacy) | [Terms](https://www.internetbrands.com/ibterms)
* Super Lawyers — https://www.superlawyers.com | [Privacy](https://www.internetbrands.com/privacy) | [Terms](https://www.internetbrands.com/ibterms)

**Healthcare**

* Healthgrades — https://www.healthgrades.com | [Privacy](https://www.healthgrades.com/content/privacy-policy) | [Terms](https://www.healthgrades.com/content/terms-of-use)
* WebMD — https://doctor.webmd.com | [Privacy](https://www.webmd.com/about-webmd-policies/about-privacy-policy) | [Terms](https://www.webmd.com/about-webmd-policies/about-terms-and-conditions-of-use)
* Vitals — https://www.vitals.com | [Privacy](https://www.vitals.com/about/privacy) | [Terms](https://www.vitals.com/about/terms)
* Zocdoc — https://www.zocdoc.com | [Privacy](https://www.zocdoc.com/privacy) | [Terms](https://www.zocdoc.com/terms)
* RateMDs — https://www.ratemds.com | [Privacy](https://www.ratemds.com/privacy/) | [Terms](https://www.ratemds.com/terms/)

**Real Estate**

* Zillow — https://www.zillow.com | [Privacy](https://www.zillowgroup.com/privacy-policy/) | [Terms](https://www.zillowgroup.com/terms-of-use/)
* Realtor.com — https://www.realtor.com | [Privacy](https://www.realtor.com/privacy-policy/) | [Terms](https://www.realtor.com/terms-of-service/)
* Homes.com — https://www.homes.com | [Privacy](https://www.homes.com/privacy-policy/) | [Terms](https://www.homes.com/terms-of-use/)
* Trulia — https://www.trulia.com | [Privacy](https://www.zillowgroup.com/privacy-policy/) | [Terms](https://www.zillowgroup.com/terms-of-use/)
* LoopNet — https://www.loopnet.com | [Privacy](https://www.costar.com/about/privacy-notice) | [Terms](https://www.loopnet.com/solutions/LoopNetTerms-of-Use)

**Automotive**

* Cars.com — https://www.cars.com | [Privacy](https://www.cars.com/about/privacy/) | [Terms](https://www.cars.com/about/terms/)
* RepairPal — https://repairpal.com | [Privacy](https://repairpal.com/privacy_policy) | [Terms](https://repairpal.com/terms_of_service)
* CarGurus — https://www.cargurus.com | [Privacy](https://www.cargurus.com/about/privacy-policy) | [Terms](https://www.cargurus.com/about/terms-of-use)
* CARFAX — https://www.carfax.com | [Privacy](https://www.carfax.com/company/privacy-statement) | [Terms](https://www.carfax.com/company/terms-of-use)

**Beauty & Wellness**

* StyleSeat — https://www.styleseat.com | [Privacy](https://www.styleseat.com/privacy) | [Terms](https://www.styleseat.com/tos-for-professionals)
* Vagaro — https://www.vagaro.com | [Privacy](https://www.vagaro.com/pro/privacy) | [Terms](https://www.vagaro.com/pro/user-agreement)
* Fresha — https://www.fresha.com | [Privacy](https://terms.fresha.com/privacy-policy) | [Terms](https://terms.fresha.com/terms-service)
* Booksy — https://booksy.com | [Privacy](https://booksy.com/en-us/p/privacy) | [Terms](https://booksy.com/en-us/p/terms)
* Mindbody — https://www.mindbodyonline.com | [Privacy](https://www.mindbodyonline.com/company/legal/privacy-policy) | [Terms](https://www.mindbodyonline.com/company/legal/terms-of-service)

**Financial**

* NAPFA — https://www.napfa.org | [Privacy](https://www.napfa.org/privacy-policy-legal-disclaimer) | [Terms](https://www.napfa.org/privacy-policy-legal-disclaimer)
* CFP Board — https://www.cfp.net | [Privacy](https://www.cfp.net/privacy-policy) | [Terms](https://www.cfp.net/terms-of-use)
* NerdWallet — https://www.nerdwallet.com | [Privacy](https://legal.atomicvest.com/usa.privacy.de3d0277-78f7-4741-9e9f-755f6b4f03ba.pdf) | [Terms](https://www.nerdwallet.com/p/terms-of-use)
* SmartAsset — https://smartasset.com | [Privacy](https://smartasset.com/privacy) | [Terms](https://smartasset.com/terms)
* XY Planning Network — https://www.xyplanningnetwork.com | [Privacy](https://www.xyplanningnetwork.com/data-privacy-policy) | [Terms](https://www.xyplanningnetwork.com/data-privacy-policy)

**Education**

* GreatSchools — https://www.greatschools.org | [Privacy](https://www.greatschools.org/gk/privacy/) | [Terms](https://www.greatschools.org/gk/terms/)
* Niche — https://www.niche.com | [Privacy](https://www.niche.com/about/privacy/) | [Terms](https://www.niche.com/about/terms/)
* Wyzant — https://www.wyzant.com | [Privacy](https://support.wyzant.com/policies-and-contact-us/privacy-policy-and-terms-of-use/privacy-policy/) | [Terms](https://support.wyzant.com/policies-and-contact-us/privacy-policy-and-terms-of-use/terms-of-use/)
* Classgap — https://www.classgap.com | [Privacy](https://www.classgap.com/en/info/privacy) | [Terms](https://www.classgap.com/en/info/terms)

**Lodging**

* TripAdvisor — https://www.tripadvisor.com | [Privacy](https://tripadvisor.mediaroom.com/us-privacy-policy) | [Terms](https://www.tripadvisor.com/pages/terms.html)
* Booking.com — https://partner.booking.com | [Privacy](https://www.booking.com/content/privacy.html) | [Terms](https://www.booking.com/content/privacy.html)
* Expedia — https://welcome.expediagroup.com | [Privacy](https://legal.expediagroup.com/privacy/privacy-and-cookies-statements/other/expedia-group-privacy) | [Terms](https://www.expediagroup.com/en-us/terms-of-use)
* Google Hotel Center — https://www.google.com/hotelprices/ | [Privacy](https://policies.google.com/privacy) | [Terms](https://policies.google.com/terms)
* Airbnb — https://www.airbnb.com | [Privacy](https://www.airbnb.com/help/article/2855) | [Terms](https://www.airbnb.com/help/article/2908)

**Pet Services**

* Rover — https://www.rover.com | [Privacy](https://www.rover.com/terms/privacy/) | [Terms](https://www.rover.com/terms/tos/)
* Wag! — https://www.wagwalking.com | [Privacy](https://safety.wagwalking.com/privacy) | [Terms](https://safety.wagwalking.com/terms)
* PetMD — https://www.petmd.com | [Privacy](https://www.petmd.com/petmd-privacy-policy) | [Terms](https://www.petmd.com/legal/conditions-of-use)
* Yelp — https://biz.yelp.com | [Privacy](https://terms.yelp.com/privacy/en_us/) | [Terms](https://terms.yelp.com/tos/en_us/)
* BringFido — https://www.bringfido.com | [Privacy](https://www.bringfido.com/privacy/) | [Terms](https://www.bringfido.com/terms/)

== Upgrade Notice ==

= 2.8.0 =
Security and WordPress.org compliance hardening: WP_Filesystem for all file writes, full output escaping, and a unique twtaeo_ prefix with an automatic one-time data migration (existing Reviews are preserved). If you connected Google Business Profile, you may need to reconnect once.

= 2.3.1 =
Security and WordPress.org compliance release. AI generation now routes through the WordPress 7.0 AI Client instead of reading core Connectors keys, the MCP endpoint enforces the same permission checks as the search endpoint, and all inline styles/scripts are now enqueued. No action required.

= 2.1.1 =
Naming update: the connected dashboard is now TWT Agency. No action required — your existing connection settings carry over unchanged.

= 2.1.0 =
WordPress 7.0 compatibility update. Requires MySQL 8.0 and recommends a 256MB PHP memory limit. Adds React DataViews rendering, Command Palette bindings, and secure credential handling via `TWT_AEO_Key_Resolver`. After updating, visit TWT AEO → Modules to confirm your configuration.

= 1.0.17 =
Adds the Company Profile module (`article:publisher`, `fb:app_id`), per-bot rate-limit controls, and `/llms-full.txt` output. **Action required:** after updating, go to Settings → Permalinks and click Save to register the new rewrite rules.
